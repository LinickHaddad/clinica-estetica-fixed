import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import { useState } from "react";
import AvaliacaoCorporal from "@/components/fichas/AvaliacaoCorporal";
import AvaliacaoFacial from "@/components/fichas/AvaliacaoFacial";
import AnamneseGluteos from "@/components/fichas/AnamneseGluteos";

export default function NovaFicha() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/cliente/:id/nova-ficha");
  const clienteId = params?.id as string;
  const [selectedType, setSelectedType] = useState<"avaliacao-corporal" | "avaliacao-facial" | "anamnese-gluteos" | null>(null);

  if (!clienteId) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Cliente não encontrado</p>
          <Button onClick={() => setLocation("/")} className="bg-[#C4748A] hover:bg-[#B0626F] text-white">
            Voltar
          </Button>
        </div>
      </div>
    );
  }

  if (!selectedType) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-2xl mx-auto px-4 py-8">
          <Button
            variant="ghost"
            onClick={() => setLocation(`/cliente/${clienteId}`)}
            className="mb-6 text-[#4A1942]"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>

          <Card className="p-8">
            <h1 className="text-3xl font-bold text-[#4A1942] mb-8">Selecione o Tipo de Ficha</h1>

            <div className="space-y-4">
              <button
                onClick={() => setSelectedType("avaliacao-corporal")}
                className="w-full p-6 border-2 border-gray-200 rounded-lg hover:border-[#C4748A] hover:bg-[#C4748A]/5 transition-all text-left"
              >
                <h3 className="text-xl font-bold text-[#4A1942] mb-2">Avaliação Corporal</h3>
                <p className="text-gray-600">Avaliação completa do corpo com dados clínicos e hábitos</p>
              </button>

              <button
                onClick={() => setSelectedType("avaliacao-facial")}
                className="w-full p-6 border-2 border-gray-200 rounded-lg hover:border-[#C4748A] hover:bg-[#C4748A]/5 transition-all text-left"
              >
                <h3 className="text-xl font-bold text-[#4A1942] mb-2">Avaliação Facial</h3>
                <p className="text-gray-600">Avaliação de pele facial, tipo de pele e rotina de cuidados</p>
              </button>

              <button
                onClick={() => setSelectedType("anamnese-gluteos")}
                className="w-full p-6 border-2 border-gray-200 rounded-lg hover:border-[#C4748A] hover:bg-[#C4748A]/5 transition-all text-left"
              >
                <h3 className="text-xl font-bold text-[#4A1942] mb-2">Anamnese Glúteos</h3>
                <p className="text-gray-600">Anamnese completa para avaliação de glúteos</p>
              </button>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  // Render selected form
  if (selectedType === "avaliacao-corporal") {
    return <AvaliacaoCorporal />;
  }

  if (selectedType === "avaliacao-facial") {
    return <AvaliacaoFacial />;
  }

  if (selectedType === "anamnese-gluteos") {
    return <AnamneseGluteos />;
  }

  return null;
}
