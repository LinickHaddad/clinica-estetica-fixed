import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Plus, Search, LogOut } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");

  const { data: clientes = [], isLoading } = trpc.clientes.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const filteredClientes = clientes.filter(c =>
    c.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.cpf?.includes(searchTerm) ||
    c.telefone?.includes(searchTerm)
  );

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#4A1942] to-[#2D0F28] px-4">
        <div className="text-center max-w-md">
          <div className="text-white mb-8">
            <h1 className="text-4xl font-bold mb-2">Clínica Estética</h1>
            <p className="text-[#C4748A] text-lg">Sistema de Gestão</p>
          </div>
          <p className="text-white/80 mb-8">
            Fichas digitais, histórico de clientes e evoluções de tratamento — tudo em um só lugar.
          </p>
          <Button
            onClick={() => window.location.href = getLoginUrl()}
            size="lg"
            className="w-full bg-white text-[#4A1942] hover:bg-gray-100 font-semibold"
          >
            Entrar com Google
          </Button>
          <p className="text-white/60 text-sm mt-6">
            Qualquer conta Google pode acessar o sistema.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-[#4A1942]">Dashboard</h1>
            <p className="text-sm text-gray-600">Bem-vindo, {user?.name || "usuário"}</p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              logout();
              setLocation("/");
            }}
            className="text-red-600 hover:text-red-700 hover:bg-red-50"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sair
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Search and Add */}
        <div className="flex gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Buscar por nome, CPF ou telefone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button
            onClick={() => setLocation("/novo-cliente")}
            className="bg-[#C4748A] hover:bg-[#B0626F] text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Cliente
          </Button>
        </div>

        {/* Clientes Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="h-40 bg-gray-200 animate-pulse" />
            ))}
          </div>
        ) : filteredClientes.length === 0 ? (
          <Card className="p-12 text-center">
            <p className="text-gray-600 mb-4">Nenhum cliente encontrado</p>
            <Button
              onClick={() => setLocation("/novo-cliente")}
              className="bg-[#C4748A] hover:bg-[#B0626F] text-white"
            >
              Criar Primeiro Cliente
            </Button>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredClientes.map((cliente) => (
              <Card
                key={cliente.id}
                className="p-6 hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => setLocation(`/cliente/${cliente.id}`)}
              >
                <h3 className="font-bold text-lg text-[#4A1942] mb-2">{cliente.nome}</h3>
                {cliente.cpf && <p className="text-sm text-gray-600">CPF: {cliente.cpf}</p>}
                {cliente.telefone && <p className="text-sm text-gray-600">Tel: {cliente.telefone}</p>}
                {cliente.email && <p className="text-sm text-gray-600">Email: {cliente.email}</p>}
                {cliente.cidade && <p className="text-sm text-gray-600">{cliente.cidade}</p>}
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full text-[#C4748A] border-[#C4748A] hover:bg-[#C4748A]/10"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation(`/cliente/${cliente.id}`);
                    }}
                  >
                    Ver Detalhes
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
