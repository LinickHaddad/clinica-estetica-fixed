import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Plus, Trash2, Eye } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useState } from "react";

export default function ClientePerfil() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/cliente/:id");
  const clienteId = params?.id as string;
  const [activeTab, setActiveTab] = useState("dados");

  const { data: cliente, isLoading: loadingCliente } = trpc.clientes.get.useQuery(
    { id: clienteId },
    { enabled: !!clienteId }
  );

  const { data: fichas = [] } = trpc.fichas.listByCliente.useQuery(
    { clienteId },
    { enabled: !!clienteId }
  );

  const { data: evolucoes = [] } = trpc.evolucoes.listByCliente.useQuery(
    { clienteId },
    { enabled: !!clienteId }
  );

  const deleteClienteMutation = trpc.clientes.delete.useMutation({
    onSuccess: () => {
      toast.success("Cliente deletado");
      setLocation("/");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao deletar");
    },
  });

  const deleteFichaMutation = trpc.fichas.delete.useMutation({
    onSuccess: () => {
      toast.success("Ficha deletada");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao deletar");
    },
  });

  const deleteEvolucaoMutation = trpc.evolucoes.delete.useMutation({
    onSuccess: () => {
      toast.success("Evolução deletada");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao deletar");
    },
  });

  if (loadingCliente) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-gray-600">Carregando...</div>
      </div>
    );
  }

  if (!cliente) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Cliente não encontrado</p>
          <Button onClick={() => setLocation("/")} className="bg-[#C4748A] hover:bg-[#B0626F] text-white">
            Voltar
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => setLocation("/")}
          className="mb-6 text-[#4A1942]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar
        </Button>

        {/* Header */}
        <Card className="p-8 mb-6">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h1 className="text-3xl font-bold text-[#4A1942]">{cliente.nome}</h1>
              <p className="text-gray-600 mt-2">
                Cadastrado em {new Date(cliente.criadoEm).toLocaleDateString("pt-BR")}
              </p>
            </div>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => {
                if (confirm("Tem certeza que deseja deletar este cliente?")) {
                  deleteClienteMutation.mutate({ id: clienteId });
                }
              }}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Deletar
            </Button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {cliente.cpf && (
              <div>
                <p className="text-sm text-gray-600">CPF</p>
                <p className="font-semibold">{cliente.cpf}</p>
              </div>
            )}
            {cliente.telefone && (
              <div>
                <p className="text-sm text-gray-600">Telefone</p>
                <p className="font-semibold">{cliente.telefone}</p>
              </div>
            )}
            {cliente.email && (
              <div>
                <p className="text-sm text-gray-600">Email</p>
                <p className="font-semibold text-sm">{cliente.email}</p>
              </div>
            )}
            {cliente.cidade && (
              <div>
                <p className="text-sm text-gray-600">Cidade</p>
                <p className="font-semibold">{cliente.cidade}</p>
              </div>
            )}
            {cliente.dataNascimento && (
              <div>
                <p className="text-sm text-gray-600">Data de Nascimento</p>
                <p className="font-semibold">{cliente.dataNascimento}</p>
              </div>
            )}
          </div>

          {cliente.observacoes && (
            <div className="mt-6 pt-6 border-t border-gray-200">
              <p className="text-sm text-gray-600 mb-2">Observações</p>
              <p className="text-gray-800">{cliente.observacoes}</p>
            </div>
          )}
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="dados">Fichas ({fichas.length})</TabsTrigger>
            <TabsTrigger value="evolucoes">Evoluções ({evolucoes.length})</TabsTrigger>
          </TabsList>

          {/* Fichas */}
          <TabsContent value="dados" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-[#4A1942]">Fichas de Avaliação</h2>
              <Button
                onClick={() => setLocation(`/cliente/${clienteId}/nova-ficha`)}
                className="bg-[#C4748A] hover:bg-[#B0626F] text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Ficha
              </Button>
            </div>

            {fichas.length === 0 ? (
              <Card className="p-8 text-center">
                <p className="text-gray-600 mb-4">Nenhuma ficha criada ainda</p>
                <Button
                  onClick={() => setLocation(`/cliente/${clienteId}/nova-ficha`)}
                  className="bg-[#C4748A] hover:bg-[#B0626F] text-white"
                >
                  Criar Primeira Ficha
                </Button>
              </Card>
            ) : (
              <div className="space-y-3">
                {fichas.map((ficha) => (
                  <Card key={ficha.id} className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="font-semibold text-[#4A1942] capitalize">
                          {ficha.tipo.replace("-", " ")}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {new Date(ficha.criadoEm).toLocaleDateString("pt-BR", {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                        {ficha.criadoPor && (
                          <p className="text-xs text-gray-500 mt-1">Por: {ficha.criadoPor}</p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setLocation(`/ficha/${ficha.id}`)}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          Ver
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => {
                            if (confirm("Deletar esta ficha?")) {
                              deleteFichaMutation.mutate({ id: ficha.id });
                            }
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Evoluções */}
          <TabsContent value="evolucoes" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-[#4A1942]">Histórico de Evoluções</h2>
              <Button
                onClick={() => setLocation(`/cliente/${clienteId}/nova-evolucao`)}
                className="bg-[#C4748A] hover:bg-[#B0626F] text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Evolução
              </Button>
            </div>

            {evolucoes.length === 0 ? (
              <Card className="p-8 text-center">
                <p className="text-gray-600 mb-4">Nenhuma evolução registrada</p>
                <Button
                  onClick={() => setLocation(`/cliente/${clienteId}/nova-evolucao`)}
                  className="bg-[#C4748A] hover:bg-[#B0626F] text-white"
                >
                  Registrar Primeira Evolução
                </Button>
              </Card>
            ) : (
              <div className="space-y-3">
                {[...evolucoes].reverse().map((evolucao) => (
                  <Card key={evolucao.id} className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="font-semibold text-[#4A1942]">{evolucao.procedimento}</h3>
                        <p className="text-sm text-gray-600">{evolucao.data}</p>
                        {evolucao.profissional && (
                          <p className="text-xs text-gray-500 mt-1">Prof: {evolucao.profissional}</p>
                        )}
                        {evolucao.observacoes && (
                          <p className="text-sm text-gray-700 mt-2">{evolucao.observacoes}</p>
                        )}
                      </div>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => {
                          if (confirm("Deletar esta evolução?")) {
                            deleteEvolucaoMutation.mutate({ id: evolucao.id });
                          }
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
