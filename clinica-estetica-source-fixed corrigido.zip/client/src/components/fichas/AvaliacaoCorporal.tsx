import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useState } from "react";
import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function AvaliacaoCorporal() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/cliente/:id/nova-ficha");
  const clienteId = params?.id as string;

  const [formData, setFormData] = useState({
    tratamento_estetico: "",
    experiencia: "",
    queixa_atual: "",
    exposicao_solar: "",
    historico_cancer: "",
    alergias: "",
    medicamentos: "",
    habitos: "" as string | string[],
    qualidade_sono: "",
    patologias: "" as string | string[],
    observacoes: "",
  });

  const createFichaMutation = trpc.fichas.create.useMutation({
    onSuccess: () => {
      toast.success("Ficha salva com sucesso!");
      setLocation(`/cliente/${clienteId}`);
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao salvar ficha");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createFichaMutation.mutate({
      clienteId,
      tipo: "avaliacao-corporal",
      dados: formData,
    });
  };

  const handleCheckboxChange = (field: string, value: string, checked: boolean) => {
    const current = Array.isArray(formData[field as keyof typeof formData]) 
      ? formData[field as keyof typeof formData] 
      : [];
    
    if (checked) {
      setFormData({
        ...formData,
        [field]: Array.isArray(current) ? [...current, value] : [value],
      });
    } else {
      setFormData({
        ...formData,
        [field]: Array.isArray(current) ? current.filter((v: string) => v !== value) : [],
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => setLocation(`/cliente/${clienteId}`)}
          className="mb-6 text-[#4A1942]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar
        </Button>

        <Card className="p-8">
          <h1 className="text-3xl font-bold text-[#4A1942] mb-8">Avaliação Corporal</h1>

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Dados Clínicos */}
            <div>
              <h2 className="text-xl font-bold text-[#4A1942] mb-4">Dados Clínicos</h2>
              <div className="space-y-4">
                <div>
                  <Label>Já fez tratamento estético?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.tratamento_estetico === "sim"}
                        onChange={(e) => setFormData({ ...formData, tratamento_estetico: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.tratamento_estetico === "nao"}
                        onChange={(e) => setFormData({ ...formData, tratamento_estetico: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                {formData.tratamento_estetico === "sim" && (
                  <>
                    <div>
                      <Label>Como foi sua experiência?</Label>
                      <div className="flex gap-4 mt-2">
                        <label className="flex items-center gap-2">
                          <input
                            type="radio"
                            value="boa"
                            checked={formData.experiencia === "boa"}
                            onChange={(e) => setFormData({ ...formData, experiencia: e.target.value })}
                          />
                          Boa
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="radio"
                            value="ruim"
                            checked={formData.experiencia === "ruim"}
                            onChange={(e) => setFormData({ ...formData, experiencia: e.target.value })}
                          />
                          Ruim
                        </label>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="queixa">Qual sua queixa atual?</Label>
                      <Input
                        id="queixa"
                        value={formData.queixa_atual}
                        onChange={(e) => setFormData({ ...formData, queixa_atual: e.target.value })}
                        placeholder="Descreva a queixa..."
                      />
                    </div>
                  </>
                )}

                <div>
                  <Label>Costume de exposição solar?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.exposicao_solar === "sim"}
                        onChange={(e) => setFormData({ ...formData, exposicao_solar: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.exposicao_solar === "nao"}
                        onChange={(e) => setFormData({ ...formData, exposicao_solar: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Histórico de câncer na família?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.historico_cancer === "sim"}
                        onChange={(e) => setFormData({ ...formData, historico_cancer: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.historico_cancer === "nao"}
                        onChange={(e) => setFormData({ ...formData, historico_cancer: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label htmlFor="alergias">Alergias a algum medicamento?</Label>
                  <Input
                    id="alergias"
                    value={formData.alergias}
                    onChange={(e) => setFormData({ ...formData, alergias: e.target.value })}
                    placeholder="Descreva as alergias..."
                  />
                </div>

                <div>
                  <Label htmlFor="medicamentos">Está tomando algum medicamento?</Label>
                  <Textarea
                    id="medicamentos"
                    value={formData.medicamentos}
                    onChange={(e) => setFormData({ ...formData, medicamentos: e.target.value })}
                    placeholder="Liste os medicamentos..."
                    rows={3}
                  />
                </div>
              </div>
            </div>

            {/* Hábitos */}
            <div>
              <h2 className="text-xl font-bold text-[#4A1942] mb-4">Hábitos</h2>
              <div className="space-y-2">
                {["Prática esportes", "Fuma", "Consome álcool", "Dorme bem"].map((habit) => (
                  <label key={habit} className="flex items-center gap-2">
                    <Checkbox
                      checked={(Array.isArray(formData.habitos) ? formData.habitos : []).includes(habit)}
                      onCheckedChange={(checked) => handleCheckboxChange("habitos", habit, !!checked)}
                    />
                    {habit}
                  </label>
                ))}
              </div>
            </div>

            {/* Qualidade do Sono */}
            <div>
              <Label>Qualidade do sono</Label>
              <div className="flex gap-4 mt-2">
                {["Bom", "Normal", "Ruim"].map((quality) => (
                  <label key={quality} className="flex items-center gap-2">
                    <input
                      type="radio"
                      value={quality}
                      checked={formData.qualidade_sono === quality}
                      onChange={(e) => setFormData({ ...formData, qualidade_sono: e.target.value })}
                    />
                    {quality}
                  </label>
                ))}
              </div>
            </div>

            {/* Patologias */}
            <div>
              <h2 className="text-xl font-bold text-[#4A1942] mb-4">Patologias</h2>
              <div className="space-y-2">
                {["Diabetes", "Hipertensão", "Cardiopatia", "Reumatismo", "Asma"].map((pathology) => (
                  <label key={pathology} className="flex items-center gap-2">
                    <Checkbox
                      checked={(Array.isArray(formData.patologias) ? formData.patologias : []).includes(pathology)}
                      onCheckedChange={(checked) => handleCheckboxChange("patologias", pathology, !!checked)}
                    />
                    {pathology}
                  </label>
                ))}
              </div>
            </div>

            {/* Observações */}
            <div>
              <Label htmlFor="obs">Observações Gerais</Label>
              <Textarea
                id="obs"
                value={formData.observacoes}
                onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                placeholder="Observações adicionais..."
                rows={4}
              />
            </div>

            {/* Buttons */}
            <div className="flex gap-4 pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => setLocation(`/cliente/${clienteId}`)}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={createFichaMutation.isPending}
                className="flex-1 bg-[#C4748A] hover:bg-[#B0626F] text-white"
              >
                {createFichaMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Salvar Ficha
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}
