import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useState } from "react";
import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function AnamneseGluteos() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/cliente/:id/nova-ficha");
  const clienteId = params?.id as string;

  const [formData, setFormData] = useState({
    espera_tratamento: "",
    sob_tratamento_medico: "",
    medicamentos: "",
    doador_sangue: "",
    alergia_medicamento: "",
    outra_alergia: "",
    vacina_30_dias: "",
    anticoagulante: "",
    crise_enxaqueca: "",
    pressao_arterial: "",
    drogas_endovenosas: "",
    anestesia_dentaria: "",
    marca_passo: "",
    herpes: "",
    bebidas_alcoolicas: "",
    antidepressivo: "",
    gravidez_suspeita: "",
    preenchimento_facial: "",
    toxina_botulinica: "",
    acido_hialuronico: "",
    projeto_solido: "",
    cicatrizacao: "",
    queloides: "",
    roacutan: "",
    patologias: "" as string | string[],
    observacoes: "",
  });

  const createFichaMutation = trpc.fichas.create.useMutation({
    onSuccess: () => {
      toast.success("Ficha salva com sucesso!");
      setLocation(`/cliente/${clienteId}`);
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao salvar ficha");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createFichaMutation.mutate({
      clienteId,
      tipo: "anamnese-gluteos",
      dados: formData,
    });
  };

  const handleCheckboxChange = (field: string, value: string, checked: boolean) => {
    const current = Array.isArray(formData[field as keyof typeof formData]) 
      ? formData[field as keyof typeof formData] 
      : [];
    
    if (checked) {
      setFormData({
        ...formData,
        [field]: Array.isArray(current) ? [...current, value] : [value],
      });
    } else {
      setFormData({
        ...formData,
        [field]: Array.isArray(current) ? current.filter((v: string) => v !== value) : [],
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => setLocation(`/cliente/${clienteId}`)}
          className="mb-6 text-[#4A1942]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar
        </Button>

        <Card className="p-8">
          <h1 className="text-3xl font-bold text-[#4A1942] mb-8">Anamnese Glúteos</h1>

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Dados Clínicos */}
            <div>
              <h2 className="text-xl font-bold text-[#4A1942] mb-4">Dados Clínicos</h2>
              <div className="space-y-4">
                <div>
                  <Label>O que espera do tratamento?</Label>
                  <Input
                    value={formData.espera_tratamento}
                    onChange={(e) => setFormData({ ...formData, espera_tratamento: e.target.value })}
                    placeholder="Descreva as expectativas..."
                  />
                </div>

                <div>
                  <Label>Atualmente está sob tratamento médico?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.sob_tratamento_medico === "sim"}
                        onChange={(e) => setFormData({ ...formData, sob_tratamento_medico: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.sob_tratamento_medico === "nao"}
                        onChange={(e) => setFormData({ ...formData, sob_tratamento_medico: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Está tomando algum medicamento?</Label>
                  <Textarea
                    value={formData.medicamentos}
                    onChange={(e) => setFormData({ ...formData, medicamentos: e.target.value })}
                    placeholder="Liste os medicamentos..."
                    rows={2}
                  />
                </div>

                <div>
                  <Label>É doador de sangue?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.doador_sangue === "sim"}
                        onChange={(e) => setFormData({ ...formData, doador_sangue: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.doador_sangue === "nao"}
                        onChange={(e) => setFormData({ ...formData, doador_sangue: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Tem alergia a algum medicamento?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.alergia_medicamento === "sim"}
                        onChange={(e) => setFormData({ ...formData, alergia_medicamento: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.alergia_medicamento === "nao"}
                        onChange={(e) => setFormData({ ...formData, alergia_medicamento: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Tem alguma outra alergia?</Label>
                  <Input
                    value={formData.outra_alergia}
                    onChange={(e) => setFormData({ ...formData, outra_alergia: e.target.value })}
                    placeholder="Descreva outras alergias..."
                  />
                </div>

                <div>
                  <Label>Tomou alguma vacina nos últimos 30 dias?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.vacina_30_dias === "sim"}
                        onChange={(e) => setFormData({ ...formData, vacina_30_dias: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.vacina_30_dias === "nao"}
                        onChange={(e) => setFormData({ ...formData, vacina_30_dias: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Está em uso de algum anticoagulante?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.anticoagulante === "sim"}
                        onChange={(e) => setFormData({ ...formData, anticoagulante: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.anticoagulante === "nao"}
                        onChange={(e) => setFormData({ ...formData, anticoagulante: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Sofre de crises de enxaqueca?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.crise_enxaqueca === "sim"}
                        onChange={(e) => setFormData({ ...formData, crise_enxaqueca: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.crise_enxaqueca === "nao"}
                        onChange={(e) => setFormData({ ...formData, crise_enxaqueca: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Tem pressão arterial alta?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.pressao_arterial === "sim"}
                        onChange={(e) => setFormData({ ...formData, pressao_arterial: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.pressao_arterial === "nao"}
                        onChange={(e) => setFormData({ ...formData, pressao_arterial: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Faz uso de drogas endovenosas?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.drogas_endovenosas === "sim"}
                        onChange={(e) => setFormData({ ...formData, drogas_endovenosas: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.drogas_endovenosas === "nao"}
                        onChange={(e) => setFormData({ ...formData, drogas_endovenosas: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Já teve anestesia dentária?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.anestesia_dentaria === "sim"}
                        onChange={(e) => setFormData({ ...formData, anestesia_dentaria: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.anestesia_dentaria === "nao"}
                        onChange={(e) => setFormData({ ...formData, anestesia_dentaria: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Tem marca-passo?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.marca_passo === "sim"}
                        onChange={(e) => setFormData({ ...formData, marca_passo: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.marca_passo === "nao"}
                        onChange={(e) => setFormData({ ...formData, marca_passo: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Tem herpes?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.herpes === "sim"}
                        onChange={(e) => setFormData({ ...formData, herpes: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.herpes === "nao"}
                        onChange={(e) => setFormData({ ...formData, herpes: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Bebe bebidas alcoólicas frequentemente?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.bebidas_alcoolicas === "sim"}
                        onChange={(e) => setFormData({ ...formData, bebidas_alcoolicas: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.bebidas_alcoolicas === "nao"}
                        onChange={(e) => setFormData({ ...formData, bebidas_alcoolicas: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Toma antidepressivo ou antipsicóticos?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.antidepressivo === "sim"}
                        onChange={(e) => setFormData({ ...formData, antidepressivo: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.antidepressivo === "nao"}
                        onChange={(e) => setFormData({ ...formData, antidepressivo: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Está grávida ou com suspeita de gestação?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.gravidez_suspeita === "sim"}
                        onChange={(e) => setFormData({ ...formData, gravidez_suspeita: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.gravidez_suspeita === "nao"}
                        onChange={(e) => setFormData({ ...formData, gravidez_suspeita: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Já fez preenchimento facial?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.preenchimento_facial === "sim"}
                        onChange={(e) => setFormData({ ...formData, preenchimento_facial: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.preenchimento_facial === "nao"}
                        onChange={(e) => setFormData({ ...formData, preenchimento_facial: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Já fez aplicação de Toxina Botulínica?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.toxina_botulinica === "sim"}
                        onChange={(e) => setFormData({ ...formData, toxina_botulinica: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.toxina_botulinica === "nao"}
                        onChange={(e) => setFormData({ ...formData, toxina_botulinica: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Usa ácido hialurônico?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.acido_hialuronico === "sim"}
                        onChange={(e) => setFormData({ ...formData, acido_hialuronico: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.acido_hialuronico === "nao"}
                        onChange={(e) => setFormData({ ...formData, acido_hialuronico: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Faz uso de Roacutan?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.roacutan === "sim"}
                        onChange={(e) => setFormData({ ...formData, roacutan: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.roacutan === "nao"}
                        onChange={(e) => setFormData({ ...formData, roacutan: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Dificuldade de cicatrização?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.cicatrizacao === "sim"}
                        onChange={(e) => setFormData({ ...formData, cicatrizacao: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.cicatrizacao === "nao"}
                        onChange={(e) => setFormData({ ...formData, cicatrizacao: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>

                <div>
                  <Label>Tem queloides?</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="sim"
                        checked={formData.queloides === "sim"}
                        onChange={(e) => setFormData({ ...formData, queloides: e.target.value })}
                      />
                      Sim
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        value="nao"
                        checked={formData.queloides === "nao"}
                        onChange={(e) => setFormData({ ...formData, queloides: e.target.value })}
                      />
                      Não
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Patologias */}
            <div>
              <h2 className="text-xl font-bold text-[#4A1942] mb-4">Patologias</h2>
              <div className="space-y-2">
                {["Tireóide", "Diabetes", "Cardiopatia", "Psoriase", "Dermatites", "Lúpus", "Osteoporose", "Vitiligo", "Epilepsia"].map((pathology) => (
                  <label key={pathology} className="flex items-center gap-2">
                    <Checkbox
                      checked={(Array.isArray(formData.patologias) ? formData.patologias : []).includes(pathology)}
                      onCheckedChange={(checked) => handleCheckboxChange("patologias", pathology, !!checked)}
                    />
                    {pathology}
                  </label>
                ))}
              </div>
            </div>

            {/* Observações */}
            <div>
              <Label htmlFor="obs">Observações Gerais</Label>
              <Textarea
                id="obs"
                value={formData.observacoes}
                onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                placeholder="Observações adicionais..."
                rows={4}
              />
            </div>

            {/* Buttons */}
            <div className="flex gap-4 pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => setLocation(`/cliente/${clienteId}`)}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={createFichaMutation.isPending}
                className="flex-1 bg-[#C4748A] hover:bg-[#B0626F] text-white"
              >
                {createFichaMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Salvar Ficha
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}
