/**
 * DashboardLayout — Sidebar fixa vinho + área de conteúdo
 * Design: Clinical Modern / Soft Professional
 * Sidebar: #4A1942 (vinho escuro), acento rosé #C4748A
 * Tipografia: Nunito (títulos), Inter (corpo)
 */

import { useAuth } from "@/contexts/AuthContext";
import {
  ClipboardList,
  FileText,
  LogOut,
  Menu,
  TrendingUp,
  Users,
  X,
} from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";

const LOGO_ICON =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663455688775/BNctGpVQgAVzozNiE8CBN4/logo-icon-N9FmnGApLW4HRXEUfEWvRa.png";

const navItems = [
  { path: "/dashboard", icon: Users, label: "Clientes" },
  { path: "/fichas", icon: FileText, label: "Fichas" },
  { path: "/evolucoes", icon: TrendingUp, label: "Evoluções" },
];

interface DashboardLayoutProps {
  children: React.ReactNode;
  title?: string;
}

export default function DashboardLayout({ children, title }: DashboardLayoutProps) {
  const { user, signOut } = useAuth();
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="px-6 py-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <img src={LOGO_ICON} alt="Logo" className="w-8 h-8 brightness-0 invert opacity-90" />
          <div>
            <p className="text-white font-bold text-base leading-tight" style={{ fontFamily: "Nunito, sans-serif" }}>
              Clínica Estética
            </p>
            <p className="text-white/50 text-xs">Sistema de Gestão</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-6 space-y-1">
        <p className="text-white/30 text-xs font-semibold uppercase tracking-wider px-3 mb-3">
          Menu
        </p>
        {navItems.map(({ path, icon: Icon, label }) => {
          const active = location === path || location.startsWith(path + "/");
          return (
            <Link key={path} href={path}>
              <a
                onClick={() => setMobileOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${
                  active
                    ? "bg-[#C4748A]/20 text-white border border-[#C4748A]/30"
                    : "text-white/70 hover:bg-white/10 hover:text-white"
                }`}
              >
                <Icon
                  size={18}
                  className={active ? "text-[#C4748A]" : "text-white/50"}
                />
                {label}
              </a>
            </Link>
          );
        })}
      </nav>

      {/* User + Logout */}
      <div className="px-4 py-4 border-t border-white/10">
        {user && (
          <div className="flex items-center gap-3 mb-3">
            {user.user_metadata?.avatar_url ? (
              <img
                src={user.user_metadata.avatar_url}
                alt={user.user_metadata?.full_name || ""}
                className="w-8 h-8 rounded-full object-cover ring-2 ring-[#C4748A]/40"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-[#C4748A]/30 flex items-center justify-center text-white text-xs font-bold">
                {user.user_metadata?.full_name?.charAt(0) || user.email?.charAt(0) || "U"}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-white text-xs font-medium truncate">
                {user.user_metadata?.full_name || "Usuário"}
              </p>
              <p className="text-white/40 text-xs truncate">{user.email}</p>
            </div>
          </div>
        )}
        <button
          onClick={handleSignOut}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-all text-sm"
        >
          <LogOut size={16} />
          Sair
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-[#F7F3F5]">
      {/* Desktop Sidebar */}
      <aside
        className="hidden lg:flex flex-col w-64 fixed inset-y-0 left-0 z-30"
        style={{ background: "#4A1942" }}
      >
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar Overlay */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-40 flex">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setMobileOpen(false)}
          />
          <aside
            className="relative w-64 flex flex-col z-50"
            style={{ background: "#4A1942" }}
          >
            <button
              onClick={() => setMobileOpen(false)}
              className="absolute top-4 right-4 text-white/60 hover:text-white"
            >
              <X size={20} />
            </button>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen">
        {/* Top bar */}
        <header className="sticky top-0 z-20 bg-white border-b border-gray-100 shadow-sm">
          <div className="flex items-center gap-4 px-6 py-4">
            <button
              className="lg:hidden text-gray-500 hover:text-gray-700"
              onClick={() => setMobileOpen(true)}
            >
              <Menu size={22} />
            </button>
            {title && (
              <h1
                className="text-xl font-bold text-[#2C1810]"
                style={{ fontFamily: "Nunito, sans-serif" }}
              >
                {title}
              </h1>
            )}
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  );
}
