import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useState } from "react";
import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function AvaliacaoFacial() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/cliente/:id/nova-ficha");
  const clienteId = params?.id as string;

  const [formData, setFormData] = useState({
    tipo_pele: "",
    alteracoes_faciais: "" as string | string[],
    rotina_skincare: "",
    protetor_solar: "",
    medicamentos: "",
    alergias: "",
    dificuldade_cicatrizacao: "",
    herpes_labial: "",
    gravidez_suspeita: "",
    anticoncepcional: "",
    antidepressivo: "",
    observacoes: "",
  });

  const createFichaMutation = trpc.fichas.create.useMutation({
    onSuccess: () => {
      toast.success("Ficha salva com sucesso!");
      setLocation(`/cliente/${clienteId}`);
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao salvar ficha");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createFichaMutation.mutate({
      clienteId,
      tipo: "avaliacao-facial",
      dados: formData,
    });
  };

  const handleCheckboxChange = (field: string, value: string, checked: boolean) => {
    const current = Array.isArray(formData[field as keyof typeof formData]) 
      ? formData[field as keyof typeof formData] 
      : [];
    
    if (checked) {
      setFormData({
        ...formData,
        [field]: Array.isArray(current) ? [...current, value] : [value],
      });
    } else {
      setFormData({
        ...formData,
        [field]: Array.isArray(current) ? current.filter((v: string) => v !== value) : [],
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => setLocation(`/cliente/${clienteId}`)}
          className="mb-6 text-[#4A1942]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar
        </Button>

        <Card className="p-8">
          <h1 className="text-3xl font-bold text-[#4A1942] mb-8">Avaliação Facial</h1>

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Tipo de Pele */}
            <div>
              <h2 className="text-xl font-bold text-[#4A1942] mb-4">Tipo de Pele</h2>
              <div className="space-y-2">
                {["Normal", "Seca", "Oleosa", "Mista", "Sensível"].map((type) => (
                  <label key={type} className="flex items-center gap-2">
                    <input
                      type="radio"
                      value={type}
                      checked={formData.tipo_pele === type}
                      onChange={(e) => setFormData({ ...formData, tipo_pele: e.target.value })}
                    />
                    {type}
                  </label>
                ))}
              </div>
            </div>

            {/* Alterações Faciais */}
            <div>
              <h2 className="text-xl font-bold text-[#4A1942] mb-4">Alterações Faciais</h2>
              <div className="space-y-2">
                {["Acne", "Rugas", "Manchas", "Flacidez", "Cicatrizes"].map((alteration) => (
                  <label key={alteration} className="flex items-center gap-2">
                    <Checkbox
                      checked={(Array.isArray(formData.alteracoes_faciais) ? formData.alteracoes_faciais : []).includes(alteration)}
                      onCheckedChange={(checked) => handleCheckboxChange("alteracoes_faciais", alteration, !!checked)}
                    />
                    {alteration}
                  </label>
                ))}
              </div>
            </div>

            {/* Rotina de Skincare */}
            <div>
              <Label htmlFor="rotina">Rotina de Skincare</Label>
              <Textarea
                id="rotina"
                value={formData.rotina_skincare}
                onChange={(e) => setFormData({ ...formData, rotina_skincare: e.target.value })}
                placeholder="Descreva a rotina de cuidados com a pele..."
                rows={3}
              />
            </div>

            {/* Protetor Solar */}
            <div>
              <Label>Usa protetor solar diariamente?</Label>
              <div className="flex gap-4 mt-2">
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="sim"
                    checked={formData.protetor_solar === "sim"}
                    onChange={(e) => setFormData({ ...formData, protetor_solar: e.target.value })}
                  />
                  Sim
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="nao"
                    checked={formData.protetor_solar === "nao"}
                    onChange={(e) => setFormData({ ...formData, protetor_solar: e.target.value })}
                  />
                  Não
                </label>
              </div>
            </div>

            {/* Medicamentos */}
            <div>
              <Label htmlFor="meds">Está tomando algum medicamento?</Label>
              <Textarea
                id="meds"
                value={formData.medicamentos}
                onChange={(e) => setFormData({ ...formData, medicamentos: e.target.value })}
                placeholder="Liste os medicamentos..."
                rows={3}
              />
            </div>

            {/* Alergias */}
            <div>
              <Label htmlFor="alergias">Alergias conhecidas</Label>
              <Input
                id="alergias"
                value={formData.alergias}
                onChange={(e) => setFormData({ ...formData, alergias: e.target.value })}
                placeholder="Descreva as alergias..."
              />
            </div>

            {/* Dificuldade de Cicatrização */}
            <div>
              <Label>Dificuldade de cicatrização?</Label>
              <div className="flex gap-4 mt-2">
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="sim"
                    checked={formData.dificuldade_cicatrizacao === "sim"}
                    onChange={(e) => setFormData({ ...formData, dificuldade_cicatrizacao: e.target.value })}
                  />
                  Sim
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="nao"
                    checked={formData.dificuldade_cicatrizacao === "nao"}
                    onChange={(e) => setFormData({ ...formData, dificuldade_cicatrizacao: e.target.value })}
                  />
                  Não
                </label>
              </div>
            </div>

            {/* Herpes Labial */}
            <div>
              <Label>Tem herpes labial?</Label>
              <div className="flex gap-4 mt-2">
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="sim"
                    checked={formData.herpes_labial === "sim"}
                    onChange={(e) => setFormData({ ...formData, herpes_labial: e.target.value })}
                  />
                  Sim
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="nao"
                    checked={formData.herpes_labial === "nao"}
                    onChange={(e) => setFormData({ ...formData, herpes_labial: e.target.value })}
                  />
                  Não
                </label>
              </div>
            </div>

            {/* Gravidez */}
            <div>
              <Label>Está grávida ou com suspeita de gestação?</Label>
              <div className="flex gap-4 mt-2">
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="sim"
                    checked={formData.gravidez_suspeita === "sim"}
                    onChange={(e) => setFormData({ ...formData, gravidez_suspeita: e.target.value })}
                  />
                  Sim
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="nao"
                    checked={formData.gravidez_suspeita === "nao"}
                    onChange={(e) => setFormData({ ...formData, gravidez_suspeita: e.target.value })}
                  />
                  Não
                </label>
              </div>
            </div>

            {/* Anticoncepcional */}
            <div>
              <Label>Usa anticoncepcional?</Label>
              <div className="flex gap-4 mt-2">
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="sim"
                    checked={formData.anticoncepcional === "sim"}
                    onChange={(e) => setFormData({ ...formData, anticoncepcional: e.target.value })}
                  />
                  Sim
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="nao"
                    checked={formData.anticoncepcional === "nao"}
                    onChange={(e) => setFormData({ ...formData, anticoncepcional: e.target.value })}
                  />
                  Não
                </label>
              </div>
            </div>

            {/* Antidepressivo */}
            <div>
              <Label>Toma antidepressivo?</Label>
              <div className="flex gap-4 mt-2">
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="sim"
                    checked={formData.antidepressivo === "sim"}
                    onChange={(e) => setFormData({ ...formData, antidepressivo: e.target.value })}
                  />
                  Sim
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="nao"
                    checked={formData.antidepressivo === "nao"}
                    onChange={(e) => setFormData({ ...formData, antidepressivo: e.target.value })}
                  />
                  Não
                </label>
              </div>
            </div>

            {/* Observações */}
            <div>
              <Label htmlFor="obs">Observações Gerais</Label>
              <Textarea
                id="obs"
                value={formData.observacoes}
                onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                placeholder="Observações adicionais..."
                rows={4}
              />
            </div>

            {/* Buttons */}
            <div className="flex gap-4 pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => setLocation(`/cliente/${clienteId}`)}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={createFichaMutation.isPending}
                className="flex-1 bg-[#C4748A] hover:bg-[#B0626F] text-white"
              >
                {createFichaMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Salvar Ficha
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}
