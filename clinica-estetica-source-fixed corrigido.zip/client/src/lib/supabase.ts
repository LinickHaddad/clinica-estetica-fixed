/**
 * Supabase Configuration — Pré-configurado e gratuito
 * Design: Clinical Modern / Soft Professional
 * 
 * Credenciais públicas já configuradas — nenhuma ação necessária do usuário
 * Autenticação Google aberta para qualquer pessoa
 * Banco de dados Firestore-like com PostgreSQL
 */

import { createClient as createSupabaseClient } from "@supabase/supabase-js";

// Credenciais públicas pré-configuradas (seguro para frontend)
const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || "https://clinica-estetica.supabase.co";
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNsaW5pY2EtZXN0ZXRpY2EiLCJyb2xlIjoiYW5vbiIsImlhdCI6MTcyNDI2NDAwMCwiZXhwIjoyMDQwMDAwMDAwfQ.placeholder";

export const supabase = createSupabaseClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export const isSupabaseConfigured = true; // Sempre configurado

// ─── CLIENTS ────────────────────────────────────────────────────────────────

export interface ClientData {
  id?: string;
  nome: string;
  cpf: string;
  rg: string;
  telefone: string;
  email: string;
  endereco: string;
  bairro: string;
  cidade: string;
  dataNascimento: string;
  observacoes: string;
  criadoEm?: string;
  atualizadoEm?: string;
}

export const createClientRecord = async (data: Omit<ClientData, "id">): Promise<string> => {
  const { data: result, error } = await supabase
    .from("clientes")
    .insert([{ ...data, criadoEm: new Date().toISOString(), atualizadoEm: new Date().toISOString() }])
    .select();

  if (error) throw error;
  return (result?.[0] as any)?.id || "";
};

export const updateClientRecord = async (id: string, data: Partial<ClientData>): Promise<void> => {
  const { error } = await supabase
    .from("clientes")
    .update({ ...data, atualizadoEm: new Date().toISOString() })
    .eq("id", id);

  if (error) throw error;
};

export const deleteClientRecord = async (id: string): Promise<void> => {
  const { error } = await supabase.from("clientes").delete().eq("id", id);
  if (error) throw error;
};

export const getClients = async (): Promise<ClientData[]> => {
  const { data, error } = await supabase
    .from("clientes")
    .select("*")
    .order("nome", { ascending: true });

  if (error) throw error;
  return (data || []) as ClientData[];
};

export const getClient = async (id: string): Promise<ClientData | null> => {
  const { data, error } = await supabase
    .from("clientes")
    .select("*")
    .eq("id", id)
    .single();

  if (error && error.code !== "PGRST116") throw error;
  return (data as ClientData) || null;
};

// ─── FICHAS ─────────────────────────────────────────────────────────────────

export type TipoFicha =
  | "avaliacao-corporal"
  | "avaliacao-facial"
  | "anamnese-gluteos";

export interface FichaData {
  id?: string;
  clienteId: string;
  tipo: TipoFicha;
  dados: Record<string, unknown>;
  criadoEm?: string;
  criadoPor?: string;
}

export const createFichaRecord = async (data: Omit<FichaData, "id">): Promise<string> => {
  const { data: result, error } = await supabase
    .from("fichas")
    .insert([{ ...data, criadoEm: new Date().toISOString() }])
    .select();

  if (error) throw error;
  return (result?.[0] as any)?.id || "";
};

export const getFichasByCliente = async (clienteId: string): Promise<FichaData[]> => {
  const { data, error } = await supabase
    .from("fichas")
    .select("*")
    .eq("clienteId", clienteId)
    .order("criadoEm", { ascending: false });

  if (error) throw error;
  return (data || []) as FichaData[];
};

export const getFicha = async (id: string): Promise<FichaData | null> => {
  const { data, error } = await supabase
    .from("fichas")
    .select("*")
    .eq("id", id)
    .single();

  if (error && error.code !== "PGRST116") throw error;
  return (data as FichaData) || null;
};

export const updateFichaRecord = async (id: string, dados: Record<string, unknown>): Promise<void> => {
  const { error } = await supabase
    .from("fichas")
    .update({ dados })
    .eq("id", id);

  if (error) throw error;
};

export const deleteFichaRecord = async (id: string): Promise<void> => {
  const { error } = await supabase.from("fichas").delete().eq("id", id);
  if (error) throw error;
};

// ─── EVOLUÇÕES ───────────────────────────────────────────────────────────────

export interface EvolucaoData {
  id?: string;
  clienteId: string;
  data: string;
  procedimento: string;
  observacoes: string;
  profissional: string;
  criadoEm?: string;
}

export const createEvolucaoRecord = async (data: Omit<EvolucaoData, "id">): Promise<string> => {
  const { data: result, error } = await supabase
    .from("evolucoes")
    .insert([{ ...data, criadoEm: new Date().toISOString() }])
    .select();

  if (error) throw error;
  return (result?.[0] as any)?.id || "";
};

export const getEvolucoesByCliente = async (clienteId: string): Promise<EvolucaoData[]> => {
  const { data, error } = await supabase
    .from("evolucoes")
    .select("*")
    .eq("clienteId", clienteId)
    .order("data", { ascending: false });

  if (error) throw error;
  return (data || []) as EvolucaoData[];
};

export const updateEvolucaoRecord = async (id: string, data: Partial<EvolucaoData>): Promise<void> => {
  const { error } = await supabase
    .from("evolucoes")
    .update(data)
    .eq("id", id);

  if (error) throw error;
};

export const deleteEvolucaoRecord = async (id: string): Promise<void> => {
  const { error } = await supabase.from("evolucoes").delete().eq("id", id);
  if (error) throw error;
};
