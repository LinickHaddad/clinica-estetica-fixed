import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";

export default function VisualizarFicha() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/cliente/:clienteId/ficha/:fichaId");
  const clienteId = params?.clienteId as string;
  const fichaId = params?.fichaId as string;

  const { data: ficha, isLoading } = trpc.fichas.get.useQuery({ id: fichaId });
  const deleteFichaMutation = trpc.fichas.delete.useMutation({
    onSuccess: () => {
      setLocation(`/cliente/${clienteId}`);
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#C4748A]" />
      </div>
    );
  }

  if (!ficha) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Ficha não encontrada</p>
          <Button onClick={() => setLocation(`/cliente/${clienteId}`)} className="bg-[#C4748A] hover:bg-[#B0626F] text-white">
            Voltar
          </Button>
        </div>
      </div>
    );
  }

  const getTipoLabel = (tipo: string) => {
    const tipos: Record<string, string> = {
      "avaliacao-corporal": "Avaliação Corporal",
      "avaliacao-facial": "Avaliação Facial",
      "anamnese-gluteos": "Anamnese Glúteos",
    };
    return tipos[tipo] || tipo;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => setLocation(`/cliente/${clienteId}`)}
          className="mb-6 text-[#4A1942]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar
        </Button>

        <Card className="p-8">
          <div className="flex justify-between items-start mb-8">
            <div>
              <h1 className="text-3xl font-bold text-[#4A1942] mb-2">{getTipoLabel(ficha.tipo)}</h1>
              <p className="text-gray-600">
                {new Date(ficha.criadoEm).toLocaleDateString("pt-BR")}
              </p>
            </div>
            <Button
              variant="destructive"
              onClick={() => {
                if (confirm("Tem certeza que deseja deletar esta ficha?")) {
                  deleteFichaMutation.mutate({ id: fichaId });
                }
              }}
              disabled={deleteFichaMutation.isPending}
            >
              {deleteFichaMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Deletar
            </Button>
          </div>

          <div className="space-y-6">
            {Object.entries(ficha.dados as Record<string, unknown>).map(([key, value]) => (
              <div key={key}>
                <h3 className="font-bold text-[#4A1942] mb-2 capitalize">{key.replace(/_/g, " ")}</h3>
                <p className="text-gray-700 whitespace-pre-wrap">
                  {Array.isArray(value) ? value.join(", ") : String(value)}
                </p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
