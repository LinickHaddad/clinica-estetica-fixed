/**
 * ClienteForm — Criar/Editar Cliente
 * Design: Clinical Modern / Soft Professional
 * Formulário em 2 colunas no desktop, 1 no mobile
 */

import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  createClientRecord,
  getClient,
  updateClientRecord,
  type ClientData as Client,
} from "@/lib/supabase";
import { ArrowLeft, Loader2, Save } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useLocation, useParams } from "wouter";

const emptyForm: Omit<Client, "id"> = {
  nome: "",
  cpf: "",
  rg: "",
  telefone: "",
  email: "",
  endereco: "",
  bairro: "",
  cidade: "",
  dataNascimento: "",
  observacoes: "",
};

export default function ClienteForm() {
  const { id } = useParams<{ id: string }>();
  const isEditing = id && id !== "novo";
  const [, navigate] = useLocation();
  const [form, setForm] = useState(emptyForm);
  const [loading, setLoading] = useState(false);
  const [loadingData, setLoadingData] = useState(!!isEditing);

  useEffect(() => {
    if (isEditing) {
      loadClient();
    }
  }, [id]);

  const loadClient = async () => {
    try {
      const data = await getClient(id!);
      if (data) {
        setForm({
          nome: data.nome || "",
          cpf: data.cpf || "",
          rg: data.rg || "",
          telefone: data.telefone || "",
          email: data.email || "",
          endereco: data.endereco || "",
          bairro: data.bairro || "",
          cidade: data.cidade || "",
          dataNascimento: data.dataNascimento || "",
          observacoes: data.observacoes || "",
        });
      }
    } catch {
      toast.error("Erro ao carregar dados do cliente");
    } finally {
      setLoadingData(false);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nome.trim()) {
      toast.error("O nome é obrigatório");
      return;
    }
    setLoading(true);
    try {
      if (isEditing) {
        await updateClientRecord(id!, form);
        toast.success("Cliente atualizado com sucesso!");
        navigate(`/clientes/${id}`);
      } else {
        const newId = await createClientRecord(form);
        toast.success("Cliente cadastrado com sucesso!");
        navigate(`/clientes/${newId}`);
      }
    } catch (err) {
      toast.error("Erro ao salvar cliente. Verifique sua conexão.");
    } finally {
      setLoading(false);
    }
  };

  if (loadingData) {
    return (
      <DashboardLayout title={isEditing ? "Editar Cliente" : "Novo Cliente"}>
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-[#C4748A]" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title={isEditing ? "Editar Cliente" : "Novo Cliente"}>
      <div className="max-w-3xl mx-auto">
        {/* Back button */}
        <button
          onClick={() => navigate(isEditing ? `/clientes/${id}` : "/dashboard")}
          className="flex items-center gap-2 text-gray-500 hover:text-[#4A1942] text-sm mb-6 transition-colors"
        >
          <ArrowLeft size={16} />
          Voltar
        </button>

        <form onSubmit={handleSubmit}>
          {/* Card: Dados Pessoais */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-4">
            <h2
              className="text-lg font-bold text-[#4A1942] mb-5 pb-3 border-b border-gray-100"
              style={{ fontFamily: "Nunito, sans-serif" }}
            >
              Dados Pessoais
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <Label htmlFor="nome" className="text-gray-700 font-medium">
                  Nome completo *
                </Label>
                <Input
                  id="nome"
                  name="nome"
                  value={form.nome}
                  onChange={handleChange}
                  placeholder="Nome da cliente"
                  className="mt-1 border-gray-200 focus:border-[#C4748A]"
                  required
                />
              </div>
              <div>
                <Label htmlFor="cpf" className="text-gray-700 font-medium">
                  CPF
                </Label>
                <Input
                  id="cpf"
                  name="cpf"
                  value={form.cpf}
                  onChange={handleChange}
                  placeholder="000.000.000-00"
                  className="mt-1 border-gray-200 focus:border-[#C4748A]"
                />
              </div>
              <div>
                <Label htmlFor="rg" className="text-gray-700 font-medium">
                  RG
                </Label>
                <Input
                  id="rg"
                  name="rg"
                  value={form.rg}
                  onChange={handleChange}
                  placeholder="00.000.000-0"
                  className="mt-1 border-gray-200 focus:border-[#C4748A]"
                />
              </div>
              <div>
                <Label htmlFor="dataNascimento" className="text-gray-700 font-medium">
                  Data de Nascimento
                </Label>
                <Input
                  id="dataNascimento"
                  name="dataNascimento"
                  type="date"
                  value={form.dataNascimento}
                  onChange={handleChange}
                  className="mt-1 border-gray-200 focus:border-[#C4748A]"
                />
              </div>
              <div>
                <Label htmlFor="telefone" className="text-gray-700 font-medium">
                  Telefone / WhatsApp
                </Label>
                <Input
                  id="telefone"
                  name="telefone"
                  value={form.telefone}
                  onChange={handleChange}
                  placeholder="(00) 00000-0000"
                  className="mt-1 border-gray-200 focus:border-[#C4748A]"
                />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="email" className="text-gray-700 font-medium">
                  E-mail
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={form.email}
                  onChange={handleChange}
                  placeholder="email@exemplo.com"
                  className="mt-1 border-gray-200 focus:border-[#C4748A]"
                />
              </div>
            </div>
          </div>

          {/* Card: Endereço */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-4">
            <h2
              className="text-lg font-bold text-[#4A1942] mb-5 pb-3 border-b border-gray-100"
              style={{ fontFamily: "Nunito, sans-serif" }}
            >
              Endereço
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <Label htmlFor="endereco" className="text-gray-700 font-medium">
                  Endereço
                </Label>
                <Input
                  id="endereco"
                  name="endereco"
                  value={form.endereco}
                  onChange={handleChange}
                  placeholder="Rua, número, complemento"
                  className="mt-1 border-gray-200 focus:border-[#C4748A]"
                />
              </div>
              <div>
                <Label htmlFor="bairro" className="text-gray-700 font-medium">
                  Bairro
                </Label>
                <Input
                  id="bairro"
                  name="bairro"
                  value={form.bairro}
                  onChange={handleChange}
                  placeholder="Bairro"
                  className="mt-1 border-gray-200 focus:border-[#C4748A]"
                />
              </div>
              <div>
                <Label htmlFor="cidade" className="text-gray-700 font-medium">
                  Cidade
                </Label>
                <Input
                  id="cidade"
                  name="cidade"
                  value={form.cidade}
                  onChange={handleChange}
                  placeholder="Cidade"
                  className="mt-1 border-gray-200 focus:border-[#C4748A]"
                />
              </div>
            </div>
          </div>

          {/* Card: Observações */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
            <h2
              className="text-lg font-bold text-[#4A1942] mb-5 pb-3 border-b border-gray-100"
              style={{ fontFamily: "Nunito, sans-serif" }}
            >
              Observações Gerais
            </h2>
            <Textarea
              id="observacoes"
              name="observacoes"
              value={form.observacoes}
              onChange={handleChange}
              placeholder="Informações adicionais sobre a cliente..."
              rows={4}
              className="border-gray-200 focus:border-[#C4748A] resize-none"
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 justify-end">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(isEditing ? `/clientes/${id}` : "/dashboard")}
              className="border-gray-200"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="bg-[#4A1942] hover:bg-[#3a1334] text-white gap-2"
            >
              {loading ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <Save size={16} />
              )}
              {loading ? "Salvando..." : isEditing ? "Atualizar" : "Cadastrar"}
            </Button>
          </div>
        </form>
      </div>
    </DashboardLayout>
  );
}
