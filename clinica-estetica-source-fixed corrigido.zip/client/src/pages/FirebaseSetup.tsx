/**
 * FirebaseSetup — Tela exibida quando Firebase não está configurado
 * Design: Clinical Modern / Soft Professional
 * Guia o usuário a configurar o Firebase antes de usar o sistema
 */

const LOGO_ICON =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663455688775/BNctGpVQgAVzozNiE8CBN4/logo-icon-N9FmnGApLW4HRXEUfEWvRa.png";

export default function FirebaseSetup() {
  return (
    <div className="min-h-screen bg-[#FDFAF9] flex items-center justify-center p-6">
      <div className="max-w-2xl w-full">
        {/* Logo */}
        <div className="flex items-center gap-3 mb-8">
          <img src={LOGO_ICON} alt="Logo" className="w-10 h-10" />
          <div>
            <p className="font-bold text-xl text-[#4A1942]" style={{ fontFamily: "Nunito, sans-serif" }}>
              Clínica Estética
            </p>
            <p className="text-gray-400 text-xs">Sistema de Gestão</p>
          </div>
        </div>

        {/* Alert */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 mb-6 flex gap-3">
          <div className="text-amber-500 text-xl shrink-0">⚙️</div>
          <div>
            <p className="font-semibold text-amber-800 mb-1" style={{ fontFamily: "Nunito, sans-serif" }}>
              Configuração do Firebase necessária
            </p>
            <p className="text-amber-700 text-sm">
              O sistema precisa das credenciais do Firebase para funcionar. Siga os passos abaixo para configurar.
            </p>
          </div>
        </div>

        {/* Steps */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-5">
          <h2 className="text-lg font-bold text-[#4A1942]" style={{ fontFamily: "Nunito, sans-serif" }}>
            Como configurar em 3 passos
          </h2>

          {[
            {
              step: "1",
              title: "Criar projeto no Firebase",
              desc: "Acesse console.firebase.google.com, crie um projeto, ative Authentication > Google e crie um banco Firestore.",
              link: "https://console.firebase.google.com",
              linkText: "Abrir Firebase Console",
            },
            {
              step: "2",
              title: "Obter as credenciais",
              desc: "No Firebase, vá em Configurações do projeto > Seus apps > Web app. Copie o objeto firebaseConfig com as 6 chaves.",
              link: null,
              linkText: null,
            },
            {
              step: "3",
              title: "Configurar variáveis de ambiente",
              desc: "Crie um arquivo .env na raiz do projeto (ou configure no Netlify) com as variáveis VITE_FIREBASE_*.",
              link: null,
              linkText: null,
            },
          ].map(({ step, title, desc, link, linkText }) => (
            <div key={step} className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-[#4A1942] text-white flex items-center justify-center text-sm font-bold shrink-0">
                {step}
              </div>
              <div className="flex-1">
                <p className="font-semibold text-[#2C1810] mb-1" style={{ fontFamily: "Nunito, sans-serif" }}>
                  {title}
                </p>
                <p className="text-gray-600 text-sm">{desc}</p>
                {link && (
                  <a
                    href={link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 mt-2 text-[#C4748A] text-sm font-medium hover:underline"
                  >
                    {linkText} →
                  </a>
                )}
              </div>
            </div>
          ))}

          {/* .env example */}
          <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
            <p className="text-xs font-semibold text-gray-500 mb-2">Arquivo .env (exemplo):</p>
            <pre className="text-xs text-gray-700 leading-relaxed overflow-x-auto">
{`VITE_FIREBASE_API_KEY=AIzaSy...
VITE_FIREBASE_AUTH_DOMAIN=meu-projeto.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=meu-projeto
VITE_FIREBASE_STORAGE_BUCKET=meu-projeto.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
VITE_FIREBASE_APP_ID=1:123456789:web:abc123`}
            </pre>
          </div>

          <p className="text-xs text-gray-400">
            Após configurar, reinicie o servidor de desenvolvimento com <code className="bg-gray-100 px-1 rounded">pnpm dev</code> e recarregue a página.
          </p>
        </div>

        {/* Guide link */}
        <p className="text-center text-gray-400 text-sm mt-4">
          Consulte o arquivo <strong>CONFIGURACAO.md</strong> no projeto para o guia completo.
        </p>
      </div>
    </div>
  );
}
