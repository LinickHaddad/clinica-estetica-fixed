/**
 * Dashboard — Lista de Clientes
 * Design: Clinical Modern / Soft Professional
 * Sidebar vinho, cards brancos com sombra suave, acento rosé
 */

import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getClients, type ClientData as Client } from "@/lib/supabase";
import {
  ChevronRight,
  Loader2,
  Phone,
  Plus,
  Search,
  User,
  Users,
} from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function Dashboard() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [, navigate] = useLocation();

  useEffect(() => {
    loadClients();
  }, []);

  const loadClients = async () => {
    try {
      setLoading(true);
      const data = await getClients();
      setClients(data);
    } catch (err) {
      toast.error("Erro ao carregar clientes");
    } finally {
      setLoading(false);
    }
  };

  const filtered = clients.filter(
    (c) =>
      c.nome.toLowerCase().includes(search.toLowerCase()) ||
      c.cpf?.includes(search) ||
      c.telefone?.includes(search)
  );

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .slice(0, 2)
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  return (
    <DashboardLayout title="Clientes">
      {/* Stats bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#4A1942]/10 flex items-center justify-center">
            <Users size={22} className="text-[#4A1942]" />
          </div>
          <div>
            <p className="text-2xl font-bold text-[#2C1810]" style={{ fontFamily: "Nunito, sans-serif" }}>
              {clients.length}
            </p>
            <p className="text-gray-500 text-sm">Total de clientes</p>
          </div>
        </div>
      </div>

      {/* Actions bar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Buscar por nome, CPF ou telefone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 bg-white border-gray-200 focus:border-[#C4748A] focus:ring-[#C4748A]/20"
          />
        </div>
        <Button
          onClick={() => navigate("/clientes/novo")}
          className="bg-[#4A1942] hover:bg-[#3a1334] text-white gap-2 shrink-0"
        >
          <Plus size={16} />
          Novo Cliente
        </Button>
      </div>

      {/* Client list */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-[#C4748A]" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-16 h-16 rounded-full bg-[#C4748A]/10 flex items-center justify-center mx-auto mb-4">
            <User size={28} className="text-[#C4748A]" />
          </div>
          <h3 className="text-lg font-semibold text-gray-700 mb-1" style={{ fontFamily: "Nunito, sans-serif" }}>
            {search ? "Nenhum cliente encontrado" : "Nenhum cliente cadastrado"}
          </h3>
          <p className="text-gray-400 text-sm mb-6">
            {search ? "Tente outro termo de busca" : "Comece cadastrando o primeiro cliente"}
          </p>
          {!search && (
            <Button
              onClick={() => navigate("/clientes/novo")}
              className="bg-[#4A1942] hover:bg-[#3a1334] text-white gap-2"
            >
              <Plus size={16} />
              Cadastrar Primeiro Cliente
            </Button>
          )}
        </div>
      ) : (
        <div className="grid gap-3">
          {filtered.map((client) => (
            <div
              key={client.id}
              onClick={() => navigate(`/clientes/${client.id}`)}
              className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 flex items-center gap-4 cursor-pointer hover:border-[#C4748A]/30 hover:shadow-md transition-all duration-200 group"
            >
              {/* Avatar */}
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#4A1942] to-[#C4748A] flex items-center justify-center text-white font-bold text-sm shrink-0">
                {getInitials(client.nome)}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-semibold text-[#2C1810]" style={{ fontFamily: "Nunito, sans-serif" }}>
                    {client.nome}
                  </h3>
                  {client.cidade && (
                    <Badge variant="secondary" className="text-xs bg-[#F7F3F5] text-gray-500 border-0">
                      {client.cidade}
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-4 mt-1 text-sm text-gray-500">
                  {client.telefone && (
                    <span className="flex items-center gap-1">
                      <Phone size={12} />
                      {client.telefone}
                    </span>
                  )}
                  {client.cpf && (
                    <span className="text-gray-400">CPF: {client.cpf}</span>
                  )}
                </div>
              </div>

              {/* Arrow */}
              <ChevronRight
                size={18}
                className="text-gray-300 group-hover:text-[#C4748A] transition-colors shrink-0"
              />
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
