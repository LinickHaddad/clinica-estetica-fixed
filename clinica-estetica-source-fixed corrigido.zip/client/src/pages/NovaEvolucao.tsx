import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useState } from "react";
import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function NovaEvolucao() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/cliente/:id/nova-evolucao");
  const clienteId = params?.id as string;

  const [formData, setFormData] = useState({
    data: new Date().toISOString().split("T")[0],
    procedimento: "",
    profissional: "",
    observacoes: "",
  });

  const createEvolucaoMutation = trpc.evolucoes.create.useMutation({
    onSuccess: () => {
      toast.success("Evolução salva com sucesso!");
      setLocation(`/cliente/${clienteId}`);
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao salvar evolução");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.procedimento || !formData.profissional) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }
    createEvolucaoMutation.mutate({
      clienteId,
      data: formData.data,
      procedimento: formData.procedimento,
      profissional: formData.profissional,
      observacoes: formData.observacoes,
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => setLocation(`/cliente/${clienteId}`)}
          className="mb-6 text-[#4A1942]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar
        </Button>

        <Card className="p-8">
          <h1 className="text-3xl font-bold text-[#4A1942] mb-8">Nova Evolução</h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="data">Data do Procedimento *</Label>
              <Input
                id="data"
                type="date"
                value={formData.data}
                onChange={(e) => setFormData({ ...formData, data: e.target.value })}
                required
              />
            </div>

            <div>
              <Label htmlFor="procedimento">Procedimento Realizado *</Label>
              <Textarea
                id="procedimento"
                value={formData.procedimento}
                onChange={(e) => setFormData({ ...formData, procedimento: e.target.value })}
                placeholder="Descreva o procedimento realizado..."
                rows={3}
                required
              />
            </div>

            <div>
              <Label htmlFor="profissional">Profissional Responsável *</Label>
              <Input
                id="profissional"
                value={formData.profissional}
                onChange={(e) => setFormData({ ...formData, profissional: e.target.value })}
                placeholder="Nome do profissional..."
                required
              />
            </div>

            <div>
              <Label htmlFor="observacoes">Observações</Label>
              <Textarea
                id="observacoes"
                value={formData.observacoes}
                onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                placeholder="Observações adicionais..."
                rows={3}
              />
            </div>

            <div className="flex gap-4 pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => setLocation(`/cliente/${clienteId}`)}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={createEvolucaoMutation.isPending}
                className="flex-1 bg-[#C4748A] hover:bg-[#B0626F] text-white"
              >
                {createEvolucaoMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Salvar Evolução
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}
