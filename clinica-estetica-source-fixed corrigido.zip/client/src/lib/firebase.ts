/**
 * Firebase Configuration
 * Design: Clinical Modern / Soft Professional
 * Uses environment variables for Firebase config (set in .env file)
 * Supports Google Auth + Firestore for full multiuser access
 *
 * SETUP: Create a .env file with your Firebase credentials:
 * VITE_FIREBASE_API_KEY=...
 * VITE_FIREBASE_AUTH_DOMAIN=...
 * VITE_FIREBASE_PROJECT_ID=...
 * VITE_FIREBASE_STORAGE_BUCKET=...
 * VITE_FIREBASE_MESSAGING_SENDER_ID=...
 * VITE_FIREBASE_APP_ID=...
 */

import { initializeApp, type FirebaseApp } from "firebase/app";
import {
  GoogleAuthProvider,
  type Auth,
  getAuth,
  signInWithPopup,
  signOut,
} from "firebase/auth";
import {
  Timestamp,
  type Firestore,
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  getFirestore,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  where,
} from "firebase/firestore";

// Check if Firebase is configured
export const isFirebaseConfigured = !!(
  import.meta.env.VITE_FIREBASE_API_KEY &&
  import.meta.env.VITE_FIREBASE_API_KEY !== "YOUR_API_KEY" &&
  import.meta.env.VITE_FIREBASE_PROJECT_ID &&
  import.meta.env.VITE_FIREBASE_PROJECT_ID !== "YOUR_PROJECT_ID"
);

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "placeholder",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "placeholder.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "placeholder",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "placeholder.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "000000000000",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:000000000000:web:placeholder",
};

let app: FirebaseApp;
let auth: Auth;
let db: Firestore;

try {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
} catch (e) {
  console.warn("Firebase initialization error:", e);
  // Will be handled by isFirebaseConfigured check in components
}

export { auth, db };

// Google Auth Provider
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: "select_account" });

export const signInWithGoogle = () => signInWithPopup(auth, googleProvider);
export const signOutUser = () => signOut(auth);

// ─── CLIENTS ────────────────────────────────────────────────────────────────

export interface Client {
  id?: string;
  nome: string;
  cpf: string;
  rg: string;
  telefone: string;
  email: string;
  endereco: string;
  bairro: string;
  cidade: string;
  dataNascimento: string;
  observacoes: string;
  criadoEm?: Timestamp;
  atualizadoEm?: Timestamp;
}

export const createClient = async (data: Omit<Client, "id">) => {
  const ref = await addDoc(collection(db, "clientes"), {
    ...data,
    criadoEm: serverTimestamp(),
    atualizadoEm: serverTimestamp(),
  });
  return ref.id;
};

export const updateClient = async (id: string, data: Partial<Client>) => {
  await updateDoc(doc(db, "clientes", id), {
    ...data,
    atualizadoEm: serverTimestamp(),
  });
};

export const deleteClient = async (id: string) => {
  await deleteDoc(doc(db, "clientes", id));
};

export const getClients = async (): Promise<Client[]> => {
  const q = query(collection(db, "clientes"), orderBy("nome"));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Client));
};

export const getClient = async (id: string): Promise<Client | null> => {
  const snap = await getDoc(doc(db, "clientes", id));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as Client;
};

// ─── FICHAS ─────────────────────────────────────────────────────────────────

export type TipoFicha =
  | "avaliacao-corporal"
  | "avaliacao-facial"
  | "anamnese-gluteos";

export interface Ficha {
  id?: string;
  clienteId: string;
  tipo: TipoFicha;
  dados: Record<string, unknown>;
  criadoEm?: Timestamp;
  criadoPor?: string;
}

export const createFicha = async (data: Omit<Ficha, "id">) => {
  const ref = await addDoc(collection(db, "fichas"), {
    ...data,
    criadoEm: serverTimestamp(),
  });
  return ref.id;
};

export const getFichasByCliente = async (clienteId: string): Promise<Ficha[]> => {
  const q = query(
    collection(db, "fichas"),
    where("clienteId", "==", clienteId),
    orderBy("criadoEm", "desc")
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Ficha));
};

export const getFicha = async (id: string): Promise<Ficha | null> => {
  const snap = await getDoc(doc(db, "fichas", id));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as Ficha;
};

export const updateFicha = async (id: string, dados: Record<string, unknown>) => {
  await updateDoc(doc(db, "fichas", id), { dados });
};

export const deleteFicha = async (id: string) => {
  await deleteDoc(doc(db, "fichas", id));
};

// ─── EVOLUÇÕES ───────────────────────────────────────────────────────────────

export interface Evolucao {
  id?: string;
  clienteId: string;
  data: string;
  procedimento: string;
  observacoes: string;
  profissional: string;
  criadoEm?: Timestamp;
}

export const createEvolucao = async (data: Omit<Evolucao, "id">) => {
  const ref = await addDoc(collection(db, "evolucoes"), {
    ...data,
    criadoEm: serverTimestamp(),
  });
  return ref.id;
};

export const getEvolucoesByCliente = async (clienteId: string): Promise<Evolucao[]> => {
  const q = query(
    collection(db, "evolucoes"),
    where("clienteId", "==", clienteId),
    orderBy("data", "desc")
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Evolucao));
};

export const updateEvolucao = async (id: string, data: Partial<Evolucao>) => {
  await updateDoc(doc(db, "evolucoes", id), data);
};

export const deleteEvolucao = async (id: string) => {
  await deleteDoc(doc(db, "evolucoes", id));
};

export { Timestamp, serverTimestamp };
