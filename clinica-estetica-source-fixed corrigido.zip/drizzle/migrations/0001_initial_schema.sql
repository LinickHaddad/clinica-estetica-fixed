CREATE TABLE IF NOT EXISTS `users` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `email` varchar(320) NOT NULL UNIQUE,
  `password` varchar(255) NOT NULL,
  `name` text,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS `clientes` (
  `id` varchar(36) PRIMARY KEY,
  `userId` int NOT NULL,
  `nome` varchar(255) NOT NULL,
  `cpf` varchar(14),
  `rg` varchar(20),
  `telefone` varchar(20),
  `email` varchar(255),
  `endereco` varchar(255),
  `bairro` varchar(100),
  `cidade` varchar(100),
  `dataNascimento` varchar(10),
  `observacoes` longtext,
  `criadoEm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizadoEm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS `fichas` (
  `id` varchar(36) PRIMARY KEY,
  `clienteId` varchar(36) NOT NULL,
  `tipo` enum('avaliacao-corporal', 'avaliacao-facial', 'anamnese-gluteos') NOT NULL,
  `dados` json NOT NULL,
  `criadoPor` varchar(255),
  `criadoEm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS `evolucoes` (
  `id` varchar(36) PRIMARY KEY,
  `clienteId` varchar(36) NOT NULL,
  `data` varchar(10) NOT NULL,
  `procedimento` varchar(255) NOT NULL,
  `observacoes` longtext,
  `profissional` varchar(255),
  `criadoEm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);
