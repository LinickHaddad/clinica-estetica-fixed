import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/sonner";
import NotFound from "@/pages/NotFound";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import NovoCliente from "@/pages/NovoCliente";
import ClientePerfil from "@/pages/ClientePerfil";
import NovaFicha from "@/pages/NovaFicha";
import NovaEvolucao from "@/pages/NovaEvolucao";
import VisualizarFicha from "@/pages/VisualizarFicha";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { useEffect, useState } from "react";

function Router({ isLoggedIn }: { isLoggedIn: boolean }) {
  if (!isLoggedIn) {
    return (
      <Switch>
        <Route path={"/*"} component={Login} />
      </Switch>
    );
  }

  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/novo-cliente"} component={NovoCliente} />
      <Route path={"/cliente/:id"} component={ClientePerfil} />
      <Route path={"/cliente/:id/nova-ficha"} component={NovaFicha} />
      <Route path={"/cliente/:id/nova-evolucao"} component={NovaEvolucao} />
      <Route path={"/ficha/:id"} component={VisualizarFicha} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean | null>(null);

  useEffect(() => {
    // Verificar se usuário está logado
    const checkAuth = async () => {
      try {
        const response = await fetch('/api/auth/me', { credentials: 'include' });
        const data = await response.json();
        setIsLoggedIn(!!data.userId);
      } catch {
        setIsLoggedIn(false);
      }
    };
    checkAuth();
  }, []);

  if (isLoggedIn === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#4A1942] to-[#2D0F2D]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-white">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router isLoggedIn={isLoggedIn} />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
